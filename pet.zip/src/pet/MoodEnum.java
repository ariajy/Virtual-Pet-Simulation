package pet;

/**
 * Represents the mood of a pet.
 */
public enum MoodEnum {
  HAPPY,
  SAD
}
