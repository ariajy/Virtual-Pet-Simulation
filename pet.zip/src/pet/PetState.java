package pet;

/**
 * Represents the state of a pet.
 */
public enum PetState {
  Active,
  Sleeping,
  Dead
}
